//
//  ProfileTableViewController.swift
//  新闻阅读APP
//
//  Created by mac on 2019/11/24.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit
import WebKit
import SVProgressHUD

class ProfileTableViewController: VisitorTableViewController {
    var webView: WKWebView! // 1. 定义 webview 对象
    override func loadView() {
        // 2. 定义 js 字符串
        let jsStr = "function haha() {window.alert('hhhha')}"
        // 3. 把定义的 js 字符串添加到脚本中去，并配置脚本对象
        let script: WKUserScript = WKUserScript(source: jsStr, injectionTime: .atDocumentEnd, forMainFrameOnly: true)

        // 4. 把脚本对象添加到页面配置中去
        let webConfiguration = WKWebViewConfiguration()
        webConfiguration.userContentController.addUserScript(script)
        
        // 5. 设置 webview 代理
        webView = WKWebView(frame: .zero, configuration: webConfiguration)
        webView.uiDelegate = self
        webView.navigationDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.configuration.userContentController.add(self, name: "testJS")
        webView.configuration.userContentController.add(self, name: "logout")
        view = webView
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if !UserAccountViewModel.sharedUserAccount.userLogin {
            visitorLoginView?.setUIInfo(imageName: "visitordiscover_image_profile", title: "登录后，查看个人信息")
        }
        // 加载本地网页
//        loadLocalWebPage()
        // 加载测试页面
        loadWebURL()

    }
    func loadLocalWebPage() {
        let path:String = Bundle.main.path(forResource: "index", ofType: "html", inDirectory: "PersonalPage")!
        let url = URL.init(fileURLWithPath: path)
        let urlRequest = URLRequest.init(url: url)
        webView.load(urlRequest)
    }
    func loadWebURL() {
        let testURL = URL(string: "http://192.168.0.100:1024/")
        let testRequest = URLRequest(url: testURL!)
        webView.load(testRequest)
    }
    
}
// MARK: WKUIDelegate
extension ProfileTableViewController: WKUIDelegate {
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        print("界面弹出了警告框")
        print("警告框的内容：\(message)")
        completionHandler()
    }
}
// MARK: WKNavigationDelegate
extension ProfileTableViewController: WKNavigationDelegate {
    // 页面开始加载时调用
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        SVProgressHUD.show()
        print("页面开始加载时调用")
    }

    // 页面内容开始返回调用
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        print("页面内容开始返回调用")
    }

    // 页面加载完成之后调用
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        SVProgressHUD.dismiss()
        webView.evaluateJavaScript("haha()") { (_, _) in
            print("完成执行js方法的回调")
        }
        print("页面加载完成之后调用")
    }

    // 页面加载失败时调用
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        print("页面加载失败时调用")
    }
    
    // 在发送请求之前，决定是否跳转
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        print("在发送请求之前，决定是否跳转")
        decisionHandler(.allow)
    }

    // 在收到响应后，决定是否跳转
    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        print("在收到响应后，决定是否跳转")
        decisionHandler(.allow)
    }

    // 接收到服务器跳转请求之后执行
    func webView(_ webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!) {
        print("接收到服务器跳转请求之后执行")
    }

}
func testJS(name: String, pass:String) {
    print("js调用原生方法, 参数name:\(name) + pass:\(pass)")
}
func logout() {
    UserAccountViewModel.sharedUserAccount.logout()
    print("js调用原生方法退出登录")
}
// 实现消息传递的代理
extension ProfileTableViewController: WKScriptMessageHandler {
    // JS调用原生方法的处理
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        print("JS 调用了\(message.name)方法，传回参数\(message.body)")
        if message.name == "testJS" {
            let data: Dictionary = message.body as! Dictionary<String, Any>
            testJS(name:data["name"] as! String, pass:data["pass"] as! String)
        } else if message.name == "logout" {
            logout()
        }
        
    }
}
