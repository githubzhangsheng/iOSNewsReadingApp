//
//  NewsObject.swift
//  新闻阅读APP
//
//  Created by mac on 2019/12/28.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit
import SwiftyJSON
/// 新闻模型
class NewsObject: NSObject {
    /// 新闻id
    var id: Int = 0
    /// 新闻标题
    var title: String?
    /// 新闻信息内容(简介)
    var text: String?
    /// 新闻发表时间
    var create_time: String?
    /// 新闻来源
    var source: String?
    /// 用户模型：即新闻作者
    var user: User?
    /// 新闻封面缩略图
    var thumb_pic: String?
    
    
    init(jsonData: JSON) {
        super.init()
        id = jsonData["id"].int!
        text = jsonData["text"].string
        create_time = jsonData["create_time"].string
        source = jsonData["source"].string
        title = jsonData["title"].string
        
        // 处理 user 的部分，这里的 user 指的是文章的作者
//        handleUser(userData: jsonData["user"])
    }
    private func handleUser(userData:JSON) {
        
    }
    
    
}
